import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthLayout } from './AuthLayout';

type PrincipalSignUpForm = {
  fullName: string;
  workEmail: string;
  phoneNumber: string;
  schoolName: string;
  schoolAddress: string;
};

const emptyForm: PrincipalSignUpForm = {
  fullName: '',
  workEmail: '',
  phoneNumber: '',
  schoolName: '',
  schoolAddress: '',
};

export function PrincipalSignUpPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState<PrincipalSignUpForm>(emptyForm);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    navigate('/auth/select-school');
  };

  return (
    <AuthLayout
      title="Principal Sign Up"
      subtitle="Create your school leadership account to begin onboarding."
      footer={
        <p>
          Already registered?{' '}
          <Link className="font-medium text-blue-700 hover:text-blue-800" to="/auth/sign-in">
            Sign in here
          </Link>
        </p>
      }
    >
      <form className="space-y-5" onSubmit={handleSubmit}>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-800" htmlFor="principal-full-name">Full Name</label>
          <input
            id="principal-full-name"
            type="text"
            required
            value={form.fullName}
            onChange={(event) => setForm((prev) => ({ ...prev, fullName: event.target.value }))}
            className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
            placeholder="e.g. Adaeze Okafor"
          />
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-800" htmlFor="principal-work-email">Work Email</label>
            <input
              id="principal-work-email"
              type="email"
              required
              value={form.workEmail}
              onChange={(event) => setForm((prev) => ({ ...prev, workEmail: event.target.value }))}
              className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
              placeholder="name@school.edu"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-800" htmlFor="principal-phone">Phone Number</label>
            <input
              id="principal-phone"
              type="tel"
              required
              value={form.phoneNumber}
              onChange={(event) => setForm((prev) => ({ ...prev, phoneNumber: event.target.value }))}
              className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
              placeholder="+234 801 234 5678"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-800" htmlFor="principal-school-name">School Name</label>
          <input
            id="principal-school-name"
            type="text"
            required
            value={form.schoolName}
            onChange={(event) => setForm((prev) => ({ ...prev, schoolName: event.target.value }))}
            className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
            placeholder="Sunrise Model Academy"
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-800" htmlFor="principal-school-address">School Address</label>
          <textarea
            id="principal-school-address"
            required
            rows={3}
            value={form.schoolAddress}
            onChange={(event) => setForm((prev) => ({ ...prev, schoolAddress: event.target.value }))}
            className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
            placeholder="123 Education Crescent, Ikeja, Lagos"
          />
        </div>

        <button
          type="submit"
          className="inline-flex w-full items-center justify-center rounded-xl bg-slate-900 px-4 py-3 text-sm font-medium text-white transition hover:bg-slate-800"
        >
          Create Account
        </button>
      </form>
    </AuthLayout>
  );
}
