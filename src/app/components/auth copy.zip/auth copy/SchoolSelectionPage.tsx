import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthLayout } from './AuthLayout';

type SchoolWorkspace = {
  id: string;
  name: string;
  address: string;
  role: 'Principal' | 'Administrator';
};

const mockSchools: SchoolWorkspace[] = [
  { id: 'sch-1', name: 'Sunrise Model Academy', address: 'Ikeja, Lagos', role: 'Principal' },
  { id: 'sch-2', name: 'Cedar Valley College', address: 'Abuja, FCT', role: 'Administrator' },
  { id: 'sch-3', name: 'Harborview High School', address: 'Port Harcourt, Rivers', role: 'Principal' },
];

export function SchoolSelectionPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [selectedSchoolId, setSelectedSchoolId] = useState(mockSchools[0]?.id || '');

  const filteredSchools = useMemo(() => {
    if (!search.trim()) return mockSchools;

    const query = search.toLowerCase();
    return mockSchools.filter(
      (school) =>
        school.name.toLowerCase().includes(query) ||
        school.address.toLowerCase().includes(query),
    );
  }, [search]);

  const handleContinue = () => {
    navigate('/');
  };

  return (
    <AuthLayout
      title="Select School"
      subtitle="Choose the school workspace you want to access."
      footer={<p>Need another school linked? Contact platform support to request access.</p>}
    >
      <div className="space-y-5">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-800" htmlFor="school-search">Search schools</label>
          <input
            id="school-search"
            type="text"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
            placeholder="Search by school name or address"
          />
        </div>

        <div className="space-y-3">
          {filteredSchools.map((school) => {
            const isSelected = selectedSchoolId === school.id;
            return (
              <button
                key={school.id}
                type="button"
                onClick={() => setSelectedSchoolId(school.id)}
                className={`w-full rounded-xl border px-4 py-4 text-left transition ${
                  isSelected
                    ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-100'
                    : 'border-slate-300 bg-white hover:border-slate-400'
                }`}
              >
                <p className="font-medium text-slate-900">{school.name}</p>
                <p className="mt-1 text-sm text-slate-600">{school.address}</p>
                <p className="mt-2 inline-flex rounded-full bg-slate-100 px-2 py-1 text-xs font-medium text-slate-700">{school.role}</p>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={handleContinue}
          disabled={!selectedSchoolId}
          className="inline-flex w-full items-center justify-center rounded-xl bg-slate-900 px-4 py-3 text-sm font-medium text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
        >
          Continue to Dashboard
        </button>
      </div>
    </AuthLayout>
  );
}
